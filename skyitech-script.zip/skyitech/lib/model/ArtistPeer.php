<?php

/**
 * Subclass for performing query and update operations on the 'artist' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ArtistPeer extends BaseArtistPeer
{
}
