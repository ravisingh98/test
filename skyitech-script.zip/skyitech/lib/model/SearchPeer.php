<?php

/**
 * Subclass for performing query and update operations on the 'search' table.
 *
 * 
 *
 * @package lib.model
 */ 
class SearchPeer extends BaseSearchPeer
{
}
