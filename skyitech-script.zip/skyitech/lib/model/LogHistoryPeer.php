<?php

/**
 * Subclass for performing query and update operations on the 'log_history' table.
 *
 * 
 *
 * @package lib.model
 */ 
class LogHistoryPeer extends BaseLogHistoryPeer
{
}
