<?php

/**
 * Subclass for representing a row from the 'search' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Search extends BaseSearch
{
}
