<?php

/**
 * Subclass for representing a row from the 'updates_app' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UpdatesApp extends BaseUpdatesApp
{
}
