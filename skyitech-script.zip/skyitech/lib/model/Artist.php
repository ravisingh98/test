<?php

/**
 * Subclass for representing a row from the 'artist' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Artist extends BaseArtist
{
}
