<?php

/**
 * Subclass for performing query and update operations on the 'updates_app' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UpdatesAppPeer extends BaseUpdatesAppPeer
{
}
