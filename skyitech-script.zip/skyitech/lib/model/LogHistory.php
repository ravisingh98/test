<?php

/**
 * Subclass for representing a row from the 'log_history' table.
 *
 * 
 *
 * @package lib.model
 */ 
class LogHistory extends BaseLogHistory
{
}
