<h2>You Crossed Downloading Limit</h2>
<div class="info">Today You have downloaded many files..
<br />you can download more files tomorrow ...
</div>
<Br />
<?
unset($_SESSION['downloads']);
?>