<?php // This file is protected by copyright law and provided under license. Reverse engineering of this file is strictly prohibited.
eval(base64_decode('Pz48P3BocAokYk9Bd1pFTlJQID0gYXJyYXkoCid2ZXJzaW9uJz0+JzUuMCcsCidsYXN0dXBkYXRlJz0+JzIwMTEtMDEtMjUnLAonbGluayc9PidodHRwOi8vd3d3LnhtbC1zaXRlbWFwcy5jb20vbmV3cy0yMDExMDEyNS5odG1sJwopOwo/Pg=='));
?>